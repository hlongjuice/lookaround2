<?php

namespace App\Providers;

//use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use App\Models\Content;
use App\Models\ImageSilder;
use App\Models\Category;
use Session;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $news_ticker=Content::where('category_id',8)->first();
        View::share('news_ticker', $news_ticker);


        /*Module Image Slider */
        $images=ImageSilder::all();
        View::share('images',$images);
//        $advertisements=Content::with('category')->where('category_id',15)->get();
        /* User SortByDesc for get data max to min and use
            and Use Take() for limit query
        */
//        $advertisements=$advertisements->sortByDesc('id')->take(5);
//        View::share('advertisements',$advertisements);

        /* Activity */
//        $activities=Content::with('category')->where('category_id','!=',15)->where('category_id','!=',8)->get();
//        $activities=$activities->sortByDesc('id')->take(4);
//        View::share('activities',$activities);


        /*School Info*/
        $school_info=Category::where('id',72)->first()->getDescendants();
        View::share('school_info',$school_info);
        /*All Department*/
        /*Academic*/
        $academic_department=Category::where('id',9)->first()->getDescendants();
        View::share('academic_department',$academic_department);
        /*Management*/
        $management_department=Category::where('id',20)->first()->getDescendants();
        View::share('management_department',$management_department);
        /*Development*/
        $development_department=Category::where('id',19)->first()->getDescendants();
        View::share('development_department',$development_department);
        /*Plans*/
        $plans_department=Category::where('id',21)->first()->getDescendants();
        View::share('plans_department',$plans_department);











        /*News Ticker*/
//        $news_ticker=Content::where('category_id',8)->first();

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
