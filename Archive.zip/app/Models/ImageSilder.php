<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImageSilder extends Model
{
    protected $table='image_slider';

}
