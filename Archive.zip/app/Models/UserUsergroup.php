<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserUsergroup extends Model
{
    protected $table='user_usergroups';
}
