<?php

namespace App\Models;
use Baum\Node;

use Illuminate\Database\Eloquent\Model;

class Category extends Node
{
    protected $table='categories';
    protected $parentColumn='parent_id';
    protected $fillable=['title','parent_id','level'];


    public function contents()
    {
        return $this->hasMany('App\Models\Content');
    }

    public function child()
    {
        return $this->hasMany('App\Models\Category','parent_id');
    }
    public function documents()
    {
        return $this->hasMany('App\Models\Document');
    }
}
