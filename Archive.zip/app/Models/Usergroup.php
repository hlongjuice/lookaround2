<?php

namespace App\Models;

use Baum\Node;
use Illuminate\Database\Eloquent\Model;

class Usergroup extends Node
{
    protected $fillable=['parent_id','title'];

    public function users ()
    {
        return $this->belongsToMany('App\Models\User','user_usergroup','user_id','usergroup_id');
    }
}
