<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Youtube extends Model
{
    protected $table='youtube';
    protected $fillable=['title','link','feature'];
}
