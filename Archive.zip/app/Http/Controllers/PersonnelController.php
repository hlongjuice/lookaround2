<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Division;
use App\Models\Personnel;
use App\Models\Rank;
use Illuminate\Http\Request;

use App\Http\Requests;

class PersonnelController extends Controller
{
    private $director_id=1;
    private $deputy_director_id=2;
    public function index()
    {
        $big_boss=Personnel::with('divisions','duties','rank','graduation','department')
            ->where('rank_id',$this->director_id)
            ->orwhere('rank_id',$this->deputy_director_id)
            ->get();
//        dd($big_boss);
        $teachers=Personnel::with('divisions','duties','rank','graduation','department')
            ->get();
        $departments=Department::has('personnel')->get();

        $employees=Rank::where('level',6)
            ->orwhere('level',7)
            ->has('personnel')
            ->get();


        return view('personnel.index')
            ->with([
                'big_boss'=>$big_boss,
                'teacher'=>$teachers,
                'departments'=>$departments,
                'employees'=>$employees
            ]);
    }
}
