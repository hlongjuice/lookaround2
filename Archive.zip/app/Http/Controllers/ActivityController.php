<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Content;
use App\Http\Requests;

class ActivityController extends Controller
{
    public function index(){

//        $activities=json_decode($request->input('activities'));
        $activities=Content::whereIn('category_id',[66,67,68,69,70])->get()->sortByDesc('created_at');
        return view('activities.index')->with('activities',$activities);
    }

    public function divisionIndex($id)
    {
        $activities=Content::with('category')->where('id',$id)->get()->sortByDesc('created_at');
        return view('activities.index')->with('activities',$activities);
    }
    public function show($id){
        $activity=Content::with('category')->where('id',$id)->first();
        return view('activities.show')->with('activity',$activity);
    }
}
