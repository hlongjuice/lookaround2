<?php

namespace App\Http\Controllers;

use App\Models\Document;
use Illuminate\Http\Request;

use App\Http\Requests;

class AdvertisementController extends Controller
{
    public function index(){
        $advertisements=Document::with('category')
            ->whereIn('category_id',[61,62,63,64,65])
            ->get()
            ->sortByDesc('updated_at');
        return view('advertisements.index')->with('advertisements',$advertisements);
    }
}
