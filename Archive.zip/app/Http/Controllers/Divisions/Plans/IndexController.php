<?php

namespace App\Http\Controllers\Divisions\Plans;

use App\Models\Category;
use App\Models\Document;
use Illuminate\Http\Request;
use App\Models\Content;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    public function index(){
        $duties=Category::where('id',21)->first()->getDescendants();
        $activities=Content::with('category')->where('category_id',70)->get();
        $last_activities=$activities->sortByDesc('id')->take(4);
        $advertisements=Document::with('category')->where('category_id',65)->get();
        $last_advertisements=$advertisements->sortByDesc('created_at')->take(5);
        return view('divisions.academic_index')
            ->with([
                'activities'=>$activities,
                'last_activities'=>$last_activities,
                'advertisements'=>$advertisements,
                'last_advertisements'=>$last_advertisements,
                'duties'=>$duties
            ]);
    }
}
