<?php

namespace App\Http\Controllers\Divisions\Academic;

use App\Models\Category;
use App\Models\Document;
use Illuminate\Http\Request;
use App\Models\Content;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    public function index(){

        $departments=Category::where('id',9)->first()->getDescendants();
        $activities=Content::with('category')->where('category_id',67)->get();
        $last_activities=$activities->sortByDesc('id')->take(4);
        $advertisements=Document::with('category')->where('category_id',62)->get();
        $last_advertisements=$advertisements->sortByDesc('created_at')->take(5);

//        return view('divisions.academic');
//        echo 'Yo!!!';
//        return route()
        return view('divisions.academic_index')
            ->with([
                'activities'=>$activities,
                'last_activities'=>$last_activities,
                'advertisements'=>$advertisements,
                'last_advertisements'=>$last_advertisements,
                'departments'=>$departments
            ]);
    }
}
//Backup
//        $documents=Document::where('category_id',9)->get();
//        $documents=$documents->sortByDesc('created_at')->take(5);
//
//        $division=Category::where('id',9)->first();
//        $duties=Category::where('id',9)->first()->getDescendants();
//
//        $activity_path='divisions.academic.activities.index';
//        $document_path='divisions.academic.documents.index';
//
//        return view('divisions.academic.index')->with(['activities'=>$activities,
//            'documents'=>$documents,
//            'division'=>$division,
//            'activity_path'=>$activity_path,
//            'activity_show_path'=>$activity_show_path,
//            'document_path'=>$document_path,
//            'duties'=>$duties]);