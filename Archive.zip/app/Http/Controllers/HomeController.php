<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Models\Content;
use App\Models\Document;
use App\Models\ImageSilder;
use App\Models\Youtube;
use Awjudd\FeedReader\Facades\FeedReader;
use Illuminate\Http\Request;
use SimplePie;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        /*Module Image Slider */
        $images=ImageSilder::all();

        $advertisements=Document::with('category')->whereIn('category_id',[61,62,63,64,65])->get();
        /* User SortByDesc for get data max to min and use
            and Use Take() for limit query
        */
        $last_advertisements=$advertisements->sortByDesc('updated_at')->take(8);

        /* Activity */
        $activities=Content::with('category')->whereIn('category_id',[66,67,68,69,70])->get();
        $last_activities=$activities->sortByDesc('updated_at')->take(4);

        /*Document*/
        $documents=Document::with('category')->whereIn('category_id',[9,19,20,21])->get();
        $documents=$documents->sortByDesc('created_at')->take(5);
        $document_path='documentss.index';

//        $rss=FeedReader::read('http://www.kroobannok.com/rss.xml');
//        $rss=FeedReader::read('http://www.surin3.net/edunews/kroobannok.xml');
//        $rss=FeedReader::read('http://rssfeeds.sanook.com/rss/feeds/sanook/news.index.xml');
        $rss = new SimplePie();
//        $rss->set_feed_url("http://rssfeeds.sanook.com/rss/feeds/sanook/news.index.xml");
        $rss->set_feed_url("http://www.moe.go.th/rss/rss_news2.xml");
        $rss->enable_cache(false);
        $rss->set_item_limit(6);
        $rss->init();

        $youtube=Youtube::all();
        $youtube=$youtube->sortByDesc('updated_at')->first();

        return view('index')->with([
//            'advertisements'=>$advertisements,
            'last_advertisements'=>$last_advertisements,
            'activities'=>$activities,
            'last_activities'=>$last_activities,
            'documents'=>$documents,
            'document_path'=>$document_path,
            'images'=>$images,
            'rss'=>$rss,
            'youtube'=>$youtube
        ]);
    }

}
