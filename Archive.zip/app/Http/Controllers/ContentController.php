<?php

namespace App\Http\Controllers;

use App\Models\Content;
use Illuminate\Http\Request;
use DB;

use App\Http\Requests;

class ContentController extends Controller
{
    public function index()
    {
        $contents=Content::with('category')->get();

        /* User SortByDesc for get data max to min and use
            and Use Take() for limit query
        */
        $contents=$contents->sortByDesc('id')->take(5);
        return view('contents.index')->with('contents',$contents);
    }

    public function show($id)
    {
        $content=Content::find($id);

        return view('contents.show')->with('content',$content);
    }
}
