<?php

namespace App\Http\Controllers\Admin;

use App\Models\Division;
use App\Models\Document;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Category;
use Storage;
use File;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use PhpParser\Comment\Doc;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index($division_id)
    {
        $cat_id=[];
        $categories=Category::where('id',$division_id)->first()->getDescendants();
        foreach($categories as $category)
        {
            $cat_id[]=$category->id;
        }
        $divisions=Category::where('id',$division_id)->first();

//        print_r($cat_id);
        $documents=Document::with('category')
            ->whereIn('category_id',$cat_id)
            ->get()
            ->sortByDesc('updated_at');
        return view('admin.documents.index')
            ->with(['documents'=>$documents,'division_id'=>$division_id,'division'=>$divisions]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($division_id)
    {
        $text='';
       $root_cat=Category::where('id',$division_id)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {

                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
//
        return view('admin.documents.add_document')
            ->with(['categories'=>$arr_category,'division_id'=>$division_id,
                'division'=>$root_cat]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,$division_id)
    {
        $this->validate($request,[
            'title'=>'required',
            'file'=>'required',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'file.required'=>'กรุณาเลือกไฟล์',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        /*If Validate pass do this*/
        $file_path='';
        $document=new Document();
//        $document->file_path=strstr($request->input('file'),'documents');
//        $file_path=$request->input('file');
//        if (Input::file('image')->isValid()) {
        if($request->hasFile('file'))
        {
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension);//Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->title=$request->input('title');
            $document->file_path=$file_path;
            $document->category_id=$request->input('category');

            $document->save();
        }


        return redirect()->route('admin.documents.index',$division_id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($division_id,$id)
    {
        $text='';
        $arr_category=[];
//        $root_cat=Category::root();
        $root_cat=Category::where('id',$division_id)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
//            $count=count($root_cat->getDescendants()); //count data for skip last data
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {

                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }

        $document=Document::where('id',$id)->first();
//
        return view('admin.documents.edit')
            ->with(['categories'=>$arr_category,
                'document'=>$document,
                'division'=>$root_cat]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$division_id, $id)
    {

        $this->validate($request,[
            'title'=>'required',
            'file'=>'required',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'file.required'=>'กรุณาเลือกไฟล์',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        $document=Document::where('id',$id)->first();

        $document->title=$request->input('title');
        $document->category_id=$request->input('category');
        if($request->hasFile('new_file'))
        {
            File::delete($document->file_path); //Delete Old File
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('new_file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension); //Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('new_file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->file_path=$file_path;
        }

        $document->save();

        return redirect()->route('admin.documents.index',$division_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $document=Document::where('id',$id)->first();
        File::delete($document->file_path);
//        Storage::delete('uploads/70926.Exponential Smoothhing.xlsx');
        if($document->delete())
        {
            return 1;
        }
        else
            return false;
    }

}
