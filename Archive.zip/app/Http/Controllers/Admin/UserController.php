<?php

namespace App\Http\Controllers\Admin;

use App\Models\Usergroup;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');

    }

    public function index()
    {
//        $users=User::with('usergroup')->get();
        $users=User::with('usergroups')->get();

//        echo $users;
//        foreach($users as $user)
//        {
//            echo $user->usergroup.'<br>';
//        }

        return view('admin.users.index')->with('users',$users);
//        echo $users;

//        $usergroup=Usergroup::create(['title'=>'admin']);



//        return view('admin.users.index')->with('users',$users);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.users.create_user');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'username'=>'required|min:5|unique:users',
            'password'=>'required|confirmed|min:6'
//            'description'=>'required',
        ],[
            'username.required' =>'กรุณากรอก Username',
            'username.min'=>'ใส่ข้อมูลอย่างน้อย 5 ตัว',
            'username.unique'=>'username นี้มีการใช้งานแล้ว',
            'password.required'=>'กรุณากรอกรหัสผ่าน',
            'password.confirmed'=>'รหัสผ่านไม่เหมือนกัน'
        ]);

        $user =new User();
        $user->username=$request->input('username');
        $user->name=$request->input('name');
        $user->lastname=$request->input('lastname');
        $user->email=$request->input('email');
        $user->password=bcrypt($request->input('password'));

        $user->save();

        foreach($request->input('usergroup') as $usergroup)
        {
            $user->usergroups()->attach($usergroup);
        }

//        $user_group=Usergroup::where('title','admin')->first();
//        $user_group->users()->attach($user->id);

        return redirect()->route('admin.users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=User::with('usergroups')->where('id',$id)->first();
        return view('admin.users.edit')->with('user',$user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        echo "Yo!!!";
        $user=User::Where('id',$id)->first();
        $user->name=$request->input('name');
        $user->lastname=$request->input('lastname');
        $user->email=$request->input('email');
        $user->save();

        $user->usergroups()->detach();
        foreach($request->input('usergroup') as $usergroup)
        {
            $user->usergroups()->attach($usergroup);
        }
        return redirect()->route('admin.index');
//        echo $user->name;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user=User::where('id',$id)->first();
        if($user->delete())
        {
            $user->usergroups()->detach();
            return 1;
        }
        else
            return false;
    }

}
