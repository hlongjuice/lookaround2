<?php

namespace App\Http\Controllers\Admin\SuperAdmin;

use App\Models\Category;
use App\Models\Document;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use File;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SchoolInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     *
     */
    private $parent_category='72';
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
        $cat_id=[];
        $categories=Category::where('id',$this->parent_category)->first()->getDescendants();
        foreach($categories as $category)
        {
            $cat_id[]=$category->id;
        }
        $documents=Document::with('category')
            ->whereIn('category_id',$cat_id)
            ->get()
            ->sortByDesc('updated_at');
        return view('admin.super_admin.school_info.index')->with('documents',$documents);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $text='';
        $root_cat=Category::where('id',$this->parent_category)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {

                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
//
        return view('admin.super_admin.school_info.add')
            ->with('categories',$arr_category);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
            'file'=>'required',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'file.required'=>'กรุณาเลือกไฟล์',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        /*If Validate pass do this*/
        $document=new Document();
        if($request->hasFile('file'))
        {
            $user=Auth::user()->username;
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension);//Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName =$time.'.'. $user .'.' . $extension; // renameing image
            $request->file('file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->title=$request->input('title');
            $document->file_path=$file_path;
            $document->category_id=$request->input('category');

            $document->save();
        }


        return redirect()->route('super_admin.school_info.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $text='';
        $root_cat=Category::where('id',$this->parent_category)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {

                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
        $document=Document::with('category')->where('id',$id)->first();
//
        return view('admin.super_admin.school_info.edit')
            ->with([
                'categories'=>$arr_category,
                'document'=>$document
            ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title'=>'required',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        $document=Document::where('id',$id)->first();

        $document->title=$request->input('title');
        $document->category_id=$request->input('category');
        if($request->hasFile('new_file'))
        {
            $user=Auth::user()->username;
            File::delete($document->file_path); //Delete Old File
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('new_file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension); //Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.'.$user.'.'. $extension; // renameing image
            $request->file('new_file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->file_path=$file_path;
        }

        $document->save();

        return redirect()->route('super_admin.school_info.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $document=Document::where('id',$id)->first();
        File::delete($document->file_path);
//        Storage::delete('uploads/70926.Exponential Smoothhing.xlsx');
        if($document->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
