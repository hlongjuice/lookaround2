<?php

namespace App\Http\Controllers\Admin\SuperAdmin;

use App\Models\Youtube;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class YoutubeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
        $youtube =Youtube::all();
        return view('admin.super_admin.youtube.index')
            ->with('youtube',$youtube);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.super_admin.youtube.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $youtube= new Youtube();

        $youtube->title=$request->input('title');

        $url = urldecode(rawurldecode($request->input('link')));
        preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $url, $matches);
//        echo $matches[1];

        $youtube->link=$matches[1];
        $youtube->feature=$request->input('feature');
        $youtube->save();

        return redirect()->route('admin.super_admin.youtube.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $youtube = Youtube::where('id',$id)->first();
        return view('admin.super_admin.youtube.edit')
            ->with('youtube',$youtube);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $youtube=Youtube::where('id',$id)->first();
        $youtube->title=$request->input('title');
        $url = urldecode(rawurldecode($request->input('link')));
        preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $url, $matches);
        $youtube->link=$matches[1];
        $youtube->feature=$request->input('feature');
        $youtube->save();

        return redirect()->route('admin.super_admin.youtube.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $youtube=Youtube::where('id',$id)->first();
        if($youtube->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
