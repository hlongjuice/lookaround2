<?php

namespace App\Http\Controllers\Admin\SuperAdmin;

use App\Models\Content;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $category_id=66;
    public function index()
    {
        $activities=Content::with('category')->where('category_id',66)->get();
//        echo "Yo!!!";
        return view('admin.super_admin.activities.index')
            ->with('activities',$activities);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.super_admin.activities.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
//            'description'=>'required',
        ],[
            'title.required' =>'กรุณากรอกหัวเรื่อง',
            'description.required'=>'กรุณาใส่ข้อมูล',
        ]);

        $content=new Content();
        $content->title=$request->input('title');
        $content->text=$request->input('description');
        $content->category_id=$this->category_id;
        $content->gallery=strstr(dirname($request->input('gallery')),'documents');//get dirname  and clear url before document
        $thumb_path='documents/.thumbs/'.strstr(dirname($request->input('gallery')),'images');
        $content->thumb_gallery=$thumb_path;
        $content->save();

        return redirect()->route('admin.super_admin.activities.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $activity=Content::with('category')->where('id',$id)->first();
        return view('admin.super_admin.activities.edit')
            ->with('activity',$activity);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $activity=Content::where('id',$id)->first();

        $activity->title=$request->input('title');
        $activity->text=$request->input('description');

        if($activity->gallery != $request->input('gallery'))
        {
            $thumb_path='documents/.thumbs/'.strstr(dirname($request->input('gallery')),'images');
            $activity->gallery=strstr(dirname($request->input('gallery')),'documents');
            $activity->thumb_gallery=$thumb_path;
        }

        $activity->save();

        return redirect()->route('admin.super_admin.activities.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
