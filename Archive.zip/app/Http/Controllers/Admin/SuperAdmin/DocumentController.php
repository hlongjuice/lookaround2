<?php

namespace App\Http\Controllers\Admin\SuperAdmin;

use App\Models\Category;
use App\Models\Document;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use File;
use App\Http\Controllers\Controller;

class DocumentController extends Controller
{
    private $categories=[61,71];

    public function __construct()
    {
        $this->middleware('auth');

    }

    public function index(){
        $documents=Document::with('category')->whereIn('category_id',$this->categories)->get();
        return view('admin.super_admin.documents.index')->with('documents',$documents);
    }

    public function create(){
        $cat=[];
        $categories=Category::whereIn('id',$this->categories)->get();
        foreach($categories as $category)
        {
           $cat[$category->id]=$category->title;
        }
        $cat=[''=>'กรุณาเลือกหมวดหมู่']+$cat;
        return view('admin.super_admin.documents.add')
            ->with([
                'categories'=>$cat
            ]);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
            'link'=>'required_without_all:file',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'link.required_without_all'=>'กรุณาใส่ Url หรือ เลือกไฟล์',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        $document=new Document();
        $document->title=$request->input('title');
        $document->category_id=$request->input('category');
        if($request->hasFile('file'))
        {
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension);//Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->title=$request->input('title');
            $document->file_path=$file_path;
            $document->category_id=$request->input('category');


        }
        else
        {
            $document->link=$request->input('link');
        }
        $document->save();

        return redirect()->route('super_admin.documents.index');
    }

    public function edit($id)
    {
        $cat=[];
        $document=Document::with('category')->where('id',$id)->first();
        $categories=Category::whereIn('id',$this->categories)->get();
        foreach($categories as $category)
        {
            $cat[$category->id]=$category->title;
        }
        $cat=[''=>'กรุณาเลือกหมวดหมู่']+$cat;
        return view('admin.super_admin.documents.edit')
            ->with([
                'document'=>$document,
                'categories'=>$cat
            ]);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title'=>'required',
            'link'=>'required_without_all:file,new_file',
            'category'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'link.required_without_all'=>'กรุณาใส่ Url หรือ เลือกไฟล์',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        $document=Document::where('id',$id)->first();

        $document->title=$request->input('title');
        if($request->file('new_file'))
        {
            File::delete($document->file_path); //Delete Old File
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('new_file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension); //Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('new_file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->file_path=$file_path;
            $document->link=null;
        }
        else if($request->has('link'))
        {
            $document->link=$request->input('link');
            $document->file_path=null;
        }

        $document->save();

        return redirect()->route('super_admin.documents.index');
    }

    public function destroy($id){

        $document=Document::where('id',$id)->first();
        if($document->delete())
        {
            return 1;
        }
        else
            return false;

    }

}
