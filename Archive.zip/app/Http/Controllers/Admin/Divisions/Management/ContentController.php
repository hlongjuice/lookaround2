<?php

namespace App\Http\Controllers\Admin\Divisions\Management;
if(!isset($_SESSION)){
    session_start();
}
use App\Models\Category;
use App\Models\Content;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ContentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
//        $contents=Content::with('category')->where('category_id',22)->get();
            $categories=Category::where('id',20)->first()->getDescendants();
            foreach($categories as $category)
            {
                $cat_id[]=$category->id;
            }
        $contents=Content::with('category')->whereIn('category_id',$cat_id)->get();
//
        return view('admin.divisions.academic.contents.index')->with('contents',$contents);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $text='';
//        $root_cat=Category::root();
        $root_cat=Category::where('id',20)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {
                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
//
        return view('admin.divisions.academic.contents.add_contents')->with('categories',$arr_category);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
           'title'=>'required',
            'description'=>'required',
            'category'=>'required'
        ],[
            'title.required' =>'กรุณากรอกหัวเรื่อง',
            'description.required'=>'กรุณาใส่ข้อมูล',
            'category.required'=>'กรุณาเลือกหมวดหมู่'
        ]);

        $content=new Content();
        $content->title=$request->input('title');
        $content->text=$request->input('description');
        $content->category_id=$request->input('category');
        $content->save();

        return redirect()->route('admin.divisions.academic.contents.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $content=Content::find($id);
//        echo $content;

        return view('admin.contents.show')->with('content',$content);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $content=Content::where('id',$id)->first();

        $text='';
        $root_cat=Category::where('id',20)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {
                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
        return view('admin.divisions.academic.contents.edit')->with(['content'=>$content,'categories'=>$arr_category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $content=Content::where('id',$id)->first();

        $content->title=$request->input('title');
        $content->text=$request->input('text');
        $content->category_id=$request->input('category');

        $content->save();

        return redirect()->route('admin.divisions.academic.contents.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
//        echo 'Yoo!!';
        $content=Content::where('id',$id)->first();
        if($content->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
