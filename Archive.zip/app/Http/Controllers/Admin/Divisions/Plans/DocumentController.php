<?php

namespace App\Http\Controllers\Admin\Divisions\Plans;

use App\Models\Division;
use App\Models\Document;
use Illuminate\Http\Request;
use App\Models\Category;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use PhpParser\Comment\Doc;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth',['except'=>'deleteDocument']);
    }
    public function index()
    {
        $categories=Category::where('id',21)->first()->getDescendants();
        foreach($categories as $category)
        {
            $cat_id[]=$category->id;
        }
        $documents=Document::with('category')->whereIn('category_id',$cat_id)->get();
        return view('admin.divisions.plans.documents.index')->with('documents',$documents);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $text='';
//        $root_cat=Category::root();
        $root_cat=Category::where('id',21)->first();

        if(empty($root_cat->getDescendants()->first()))
        {
            $arr_category=[' '=>'กรุณาเลือกหมวดหมู่'];
        }
        else
        {
            foreach($root_cat->getDescendants() as $child_cat) //get child category
            {
                for($i=0;$i<$child_cat->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of category
                }
                if($child_cat->getLevel()==1)
                    $arr_category[$child_cat->id]=$text.$child_cat->title;
                else
                    $arr_category[$child_cat->id]=$text.' '.$child_cat->title; // $arr_category["KEY"]="Values"
                $text='';
            };
            $arr_category=[''=>'กรุณาเลือกหมวดหมู่']+$arr_category;
        }
//
        return view('admin.divisions.plans.documents.add_document')->with('categories',$arr_category);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
          'title'=>'required',
//            'divisions'=>'required',
            'file'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
//            'divisions.required'=>'กรุณาเลือกหมวดหมู่',
            'file.required'=>'กรุณาเลือกไฟล์']);

        /*If Validate pass do this*/
        $document=new Document();
//        $file_name=$request->file('file')->getClientOriginalName();
//        $request->file('file')->move('documents',$file_name);
//        $file_path='documents/'.$file_name;
//        $document->file_path=$file_path;
        $document->file_path=$request->input('file');
        $document->title=$request->input('title');
        $document->category_id=$request->input('category');

        $document->save();

        return redirect()->route('admin.divisions.plans.documents.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function deleteDocument()
    {
        $document_id=$_GET['document_id'];
       $result= Document::destroy($document_id);
        return $result;
    }
}
