<?php

namespace App\Http\Controllers\Admin\Divisions\Development;

use Illuminate\Http\Request;
use App\Models\Content;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
//        $contents=Content::with('category')->where('category_id',22)->get();
        $contents=Content::with('category')->where('category_id',51)->get();

        return view('admin.divisions.development.activities.index')->with('contents',$contents);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.divisions.development.activities.add_contents');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
            'description'=>'required',
        ],[
            'title.required' =>'กรุณากรอกหัวเรื่อง',
            'description.required'=>'กรุณาใส่ข้อมูล',
        ]);

        $content=new Content();
        $content->title=$request->input('title');
        $content->text=$request->input('description');
        $content->category_id=51;
        $content->save();

        return redirect()->route('admin.divisions.development.activities.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $content=Content::find($id);
//        echo $content;

        return view('admin.divisions.development.activities.show')->with('content',$content);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $content=Content::where('id',$id)->first();

        return view('admin.divisions.development.activities.edit')->with('content',$content);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $content=Content::where('id',$id)->first();

        $content->title=$request->input('title');
        $content->text=$request->input('text');
        $content->category_id=51;

        $content->save();

        return redirect()->route('admin.divisions.development.activities.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
//        echo 'Yoo!!';
        $content=Content::where('id',$id)->first();
        if($content->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
