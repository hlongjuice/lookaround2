<?php

namespace App\Http\Controllers\Admin;

use App\Models\Usergroup;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $text='';
        $root_group=Usergroup::root();

        if(empty($root_group->getDescendants()->first()))
        {
            $arr_group=[$root_group->id=>$root_group->title];
        }
        else
        {
            foreach($root_group->getDescendants() as $child_group) //get child groupegory
            {
                for($i=0;$i<$child_group->getLevel();$i++)//check level
                {
                    $text.='-';//add '-' before text per level of groupegory
                }
                if($child_group->getLevel()==1)
                    $arr_group[$child_group->id]=$text.$child_group->title;
                else
                    $arr_group[$child_group->id]=$text.' '.$child_group->title; // $arr_groupegory["KEY"]="Values"
                $text='';
            };
            $arr_group=[$root_group->id=>$root_group->title]+$arr_group;
        }



        return view('admin.users.group.add_group')->with('groups',$arr_group);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $parent=UserGroup::where('id',$request->input('parent_id'))->first();
//        echo $parent;
        $parent->children()->create(['title'=>$request->input('title')]);
        return redirect()->route('admin.users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
