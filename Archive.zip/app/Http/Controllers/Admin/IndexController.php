<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index()
    {
        return view('admin.index');
    }
    public function academic()
    {
        return view('admin.divisions.academic.index')
            ->with([
                'division_id'=>'9',
                'activity_id'=>'67',
                'advertisement_id'=>62
            ]);
    }
    public function management()
    {
        return view('admin.divisions.management.index')
            ->with([
                'division_id'=>20,
                'activity_id'=>68,
                'advertisement_id'=>63
            ]);
    }
    public function development()
    {
        return view('admin.divisions.development.index')
            ->with([
                'division_id'=>19,
                'activity_id'=>69,
                'advertisement_id'=>64
            ]);
    }
    public function plans()
    {
        return view('admin.divisions.plans.index')
            ->with([
                'division_id'=>21,
                'activity_id'=>70,
                'advertisement_id'=>65
            ]);
    }
}
