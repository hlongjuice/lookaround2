<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use App\Models\Content;
use App\Models\Division;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function index($division_id,$activity_id)
    {

        $contents=Content::with('category')->where('category_id',$activity_id)
            ->get()->sortByDesc('updated_at');
        $division=Category::where('id',$division_id)->first();
        return view("admin.activities.index")
            ->with([
                'contents'=>$contents,
                'division'=>$division,
                'activity_id'=>$activity_id
            ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($division_id,$activity_id)
    {
        $division=Category::where('id',$division_id)->first();
        return view('admin.activities.add')
            ->with([
                'division'=>$division,
                'activity_id'=>$activity_id
            ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($division_id,$activity_id,Request $request)
    {
        $this->validate($request,[
            'title'=>'required',
//            'description'=>'required',
        ],[
            'title.required' =>'กรุณากรอกหัวเรื่อง',
            'description.required'=>'กรุณาใส่ข้อมูล',
        ]);

        $content=new Content();
        $content->title=$request->input('title');
        $content->text=$request->input('description');
        $content->category_id=$activity_id;
        $content->gallery=strstr(dirname($request->input('gallery')),'documents');//get dirname  and clear url before document
        $thumb_path='documents/.thumbs/'.strstr(dirname($request->input('gallery')),'images');
        $content->thumb_gallery=$thumb_path;
        $content->save();

        return redirect()->route('admin.activities.index',
            [
                'activity_id'=>$activity_id,
                'division_id'=>$division_id
            ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($division_id,$activity_id,$id)
    {
        $content=Content::with('category')->where('id',$id)->first();
        $division=Category::where('id',$division_id)->first();
        return view('admin.activities.edit')
            ->with(['content'=>$content,
                    'division'=>$division,
                    'activity_id'=>$activity_id
            ]);

    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$division_id,$activity_id, $id)
    {
        $content=Content::where('id',$id)->first();

        $content->title=$request->input('title');
        $content->text=$request->input('description');
        $content->category_id=$activity_id;

        if($content->gallery != $request->input('gallery'))
        {
            $thumb_path='documents/.thumbs/'.strstr(dirname($request->input('gallery')),'images');
            $content->gallery=strstr(dirname($request->input('gallery')),'documents');
            $content->thumb_gallery=$thumb_path;
        }

        $content->save();

        return redirect()->route('admin.activities.index',[$division_id,$activity_id]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($division_id,$id)
    {
//        return $id;
        $activity=Content::where('id',$id)->first();
        if($activity->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
