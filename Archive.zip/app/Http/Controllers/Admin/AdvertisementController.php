<?php

namespace App\Http\Controllers\Admin;
if(!isset($_SESSION)){
    session_start();
}
use App\Models\Category;
use App\Models\Content;
use App\Models\Document;
use Illuminate\Http\Request;
use File;
use Carbon\Carbon;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use PhpParser\Comment\Doc;

class AdvertisementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');

    }

    public function index($division_id,$advertisement_id)
    {
        $documents=Document::with('category')->where('category_id',$advertisement_id)->get();
        $division=Category::where('id',$division_id)->first();
        return view('admin.advertisements.index')
            ->with([
                'documents'=>$documents,
                'division'=>$division,
                'advertisement_id'=>$advertisement_id
            ]);
//
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($division_id,$advertisement_id)
    {
        $division=Category::where('id',$division_id)->first();
        return view('admin.advertisements.add')
            ->with([
                'division'=>$division,
                'advertisement_id'=>$advertisement_id
            ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $division_id,$advertisement_id)
    {
        $this->validate($request,[
            'title'=>'required',
            'file'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'file.required'=>'กรุณาเลือกไฟล์']);

        $document=new Document();

        $document->title=$request->input('title');
        if($request->hasFile('file'))
        {
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension);//Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->title=$request->input('title');
            $document->file_path=$file_path;
            $document->category_id=$request->input('category');
            $document->category_id=$advertisement_id;
            $document->save();
        }

        $division=Category::where('id',$division_id)->first();

        return redirect()
            ->route('admin.advertisements.index',[
                'division'=>$division,
                'advertisement_id'=>$advertisement_id
            ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($division_id,$advertisement_id,$id)
    {
        $division=Category::where('id',$division_id)->first();
        $document=Document::with('category')->where('id',$id)->first();
        return view('admin.advertisements.edit')
            ->with([
                'document'=>$document,
                'division'=>$division,
                'advertisement_id'=>$advertisement_id
            ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$division_id,$advertisement_id, $id)
    {
        $this->validate($request,[
            'title'=>'required',
            'file'=>'required'
        ],[
            'title.required'=>'กรุณากรอกข้อมูล',
            'file.required'=>'กรุณาเลือกไฟล์']);

        $document=Document::with('category')->where('id',$id)->first();
        $document->title=$request->input('title');

        if($request->hasFile('new_file'))
        {
            File::delete($document->file_path); //Delete Old File
            $destinationPath = 'documents'; // upload path
            $extension=$request->file('new_file')->getClientOriginalName();//get file name
            $extension=str_replace(' ', '_', $extension); //Replacing space with underscore
            $time=Carbon::now()->format('d-m-y');//get current date
            $fileName = $time .'.' . $extension; // renameing image
            $request->file('new_file')->move($destinationPath, $fileName); // uploading file to given path
            $file_path=$destinationPath .'/'. $fileName;
            $document->file_path=$file_path;
        }
        $document->save();

        $division=Category::where('id',$division_id)->first();

        return redirect()
            ->route('admin.advertisements.index',[
                'division'=>$division,
                'advertisement_id'=>$advertisement_id
            ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($division, $id)
    {
//        return $id;
        $document=Document::where('id',$id)->first();
        File::delete($document->file_path);
        if($document->delete())
        {
            return 1;
        }
        else
            return false;
    }
}
