<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Duty;
use Illuminate\Http\Request;
use App\Models\Document;
use App\Http\Requests;

class DocumentController extends Controller
{
    public function index($id){
        $documents=Document::with('category')->where('category_id',$id)->get();
        $documents=$documents->sortByDesc('created_at');
        return view('documents.index')
            ->with('documents',$documents);

    }

    public function allDivisionIndex(Request $request)
    {
        $advertisement=json_decode($request->input('activities'));

    }
}
