<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware'=>'web'],function(){

    Route::auth();
    Route::get('logout','Auth\AuthController@logout');

    /*********** Back End ******************/
    /*** Admin Index ***/
    Route::get('admin','Admin\IndexController@index')
        ->name('admin.index');

    Route::group(['prefix'=>'admin'],function(){

        /*Personnel*/
        Route::get('personnel_delete_division','Admin\PersonnelController@deleteDivision');
        Route::post('personnel_delete','Admin\PersonnelController@deletePersonnel');
        Route::get('divisions','Admin\PersonnelController@getDivisions');
        Route::resource('personnel','Admin\PersonnelController');

        /*Division*/
        /*Plans*/
        Route::get('plans','Admin\IndexController@plans')
            ->name('admin.divisions.plans.index');
        /*  Academic Division Index*/
        Route::get('academic','Admin\IndexController@academic')
            ->name('admin.divisions.academic.index');
        /*  Development Division Index*/
        Route::get('development','Admin\IndexController@development')
            ->name('admin.divisions.development.index');
        /*  Management Division Index*/
        Route::get('management','Admin\IndexController@management')
            ->name('admin.divisions.management.index');

        /*Document*/
        Route::get('delete_document','Admin\DocumentController@deleteDocument');
        Route::resource('documents','Admin\DocumentController');

        /*Content Categories*/
        Route::resource('categories','Admin\CategoryController');

        /*Contents*/
        Route::resource('contents','Admin\ContentController');

        /*Users*/
        Route::resource('users','Admin\UserController');
        /*UserGroup*/
        Route::resource('group','Admin\UserGroupController');
        /*Password*/
        Route::resource('password','Admin\PasswordController');

        /*News ticker*/
        Route::resource('news_ticker','Admin\NewsTickerController');

        /*Image Slider*/
        Route::resource('image_slider','Admin\ImageSliderController');


    });

    /*Super Admin*/
    Route::group(['prefix'=>'admin/super_admin'],function(){

        /*Document*/
        Route::get('documents','Admin\SuperAdmin\DocumentController@index')
            ->name('super_admin.documents.index');
        Route::get('documents/create','Admin\SuperAdmin\DocumentController@create')
            ->name('super_admin.documents.create');
        Route::post('documents/create','Admin\SuperAdmin\DocumentController@store')
            ->name('super_admin.documents.store');
        Route::get('documents/edit/{id}','Admin\SuperAdmin\DocumentController@edit')
            ->name('super_admin.documents.edit');
        Route::patch('documents/edit/{id}','Admin\SuperAdmin\DocumentController@update')
            ->name('super_admin.documents.update');
        Route::delete('documents/{id}','Admin\SuperAdmin\DocumentController@destroy')
            ->name('super_admin.documents.destroy');

        /*SchoolInfo*/
        Route::get('school_info','Admin\SuperAdmin\SchoolInfoController@index')
            ->name('super_admin.school_info.index');
        Route::get('school_info/create','Admin\SuperAdmin\SchoolInfoController@create')
            ->name('super_admin.school_info.create');
        Route::post('school_info/create','Admin\SuperAdmin\SchoolInfoController@store')
            ->name('super_admin.school_info.store');
        Route::get('school_info/edit/{id}','Admin\SuperAdmin\SchoolInfoController@edit')
            ->name('super_admin.school_info.edit');
        Route::patch('school_info/edit/{id}','Admin\SuperAdmin\SchoolInfoController@update')
            ->name('super_admin.school_info.update');
        Route::delete('school_info/{id}','Admin\SuperAdmin\SchoolInfoController@destroy')
            ->name('super_admin.school_info.destroy');

        /*Admin Youtube*/
        Route::resource('activities','Admin\SuperAdmin\ActivityController');
        Route::resource('youtube','Admin\SuperAdmin\YoutubeController');
    });

    /*Admin Advertisement*/
    Route::group(['prefix'=>'admin/advertisements'],function(){
        Route::get('division/{division_id}/document/{id}','Admin\AdvertisementController@index')
            ->name('admin.advertisements.index');
        Route::get('division/{division_id}/advertisement/{advertisement_id}','Admin\AdvertisementController@create')
            ->name('admin.advertisements.create');
        Route::post('division/{division_id}/{advertisement_id}','Admin\AdvertisementController@store')
            ->name('admin.advertisements.store');
        Route::get('division/edit/{divisions_id}/advertisement/{advertisement_id}/document/{id}','Admin\AdvertisementController@edit')
            ->name('admin.advertisements.edit');
        Route::patch('division/edit/{divisions_id}/advertisement/{advertisement_id}/document/{id}','Admin\AdvertisementController@update')
            ->name('admin.advertisements.update');

        Route::post('division/{division}/document/{document}','Admin\AdvertisementController@destroy')
            ->name('admin.advertisements.destroy');
    });

    /*Admin Activity*/
    Route::group(['prefix'=>'admin/activities'],function(){
        Route::get('division/{division_id}/{activity_id}','Admin\ActivityController@index')
            ->name('admin.activities.index');
        Route::get('division/{division_id}/activity_id/{activity_id}','Admin\ActivityController@create')
            ->name('admin.activities.create');
        Route::post('division/{division_id}/activity_store/{id}','Admin\ActivityController@store')
            ->name('admin.activities.store');
        Route::get('division/{division_id}/activity/{activity_id}/content/{id}','Admin\ActivityController@edit')
            ->name('admin.activities.edit');
        Route::patch('division/{division_id}/activity/{activity_id}/content/{id}','Admin\ActivityController@update')
            ->name('admin.activities.update');
        Route::post('division/{division_id}/activity/{id}','Admin\ActivityController@destroy')
            ->name('admin.activities.destroy');
    });

    /*Admin Document*/
    Route::group(['prefix'=>'admin/documents'],function(){
        Route::get('division/{id}','Admin\DocumentController@index')
            ->name('admin.documents.index');
        Route::get('division/create/{id}','Admin\DocumentController@create')
            ->name('admin.documents.create');
        Route::post('division/create/{id}','Admin\DocumentController@store')
            ->name('admin.documents.store');
        Route::get('division/edit/{divisions_id}/document/{id}','Admin\DocumentController@edit')
            ->name('admin.documents.edit');
        Route::patch('division/edit/{division_id}/document/{id}','Admin\DocumentController@update')
            ->name('admin.documents.update');
        Route::post('division/{id}','Admin\DocumentController@destroy')
            ->name('admin.documents.destroy');
    });



    /*End Back-End */


    /*Font-End Route */

    /*Home Index*/
    Route::resource('image-slider','Modules\ImageSliderController');
    Route::get('/','HomeController@index');

    /*Activity*/
    Route::get('activities','ActivityController@index')->name('activities.index');
    Route::get('activities/{activity_id}','ActivityController@show')
        ->name('activities.show');

    /*Advertisement*/
    Route::get('advertisements','AdvertisementController@index')
        ->name('advertisements.index');
    /*Document*/
    Route::get('documents/{id}','DocumentController@index')->name('documents.index');

    /*Personnel*/
    Route::get('personnel','PersonnelController@index')
        ->name('personnel.index');


    Route::get('/contents','ContentController@index')->name('contents.index');
    Route::get('/contents/show/{id}','ContentController@show')->name('contents.show');
    /*End Home*/





    /*Division Academic*/
    Route::get('/divisions/academic','Divisions\Academic\IndexController@index')
        ->name('divisions.academic.index');

    /*Division Management*/
    Route::get('/divisions/management','Divisions\Management\IndexController@index')
        ->name('divisions.management.index');

    /*Division Development */
    Route::get('/divisions/development','Divisions\Development\IndexController@index')
        ->name('divisions.development.index');

    /*Division Plans*/
    Route::get('/divisions/plans','Divisions\Plans\IndexController@index')
        ->name('divisions.plans.index');

    Route::get('js/kcfinder/',function(){
       return view('login');
    });

});
