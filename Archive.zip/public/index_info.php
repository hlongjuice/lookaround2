<?php
	phpinfo();
?>